# 메모밍채널 :: Github Test Repo

#### ***바로 사용하는 초간단 Github(깃허브)***
https://www.youtube.com/playlist?list=PL-QFFQeuiKKsucSnfUbNW0BD2Aq8lk3xN
